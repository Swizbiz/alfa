package com.swizbizy.alfa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AlfaApplication {

	public static void main(String[] args) {
		SpringApplication.run(AlfaApplication.class, args);
	}

}
